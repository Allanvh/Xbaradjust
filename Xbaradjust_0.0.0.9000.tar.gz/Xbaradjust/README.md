# Xbaradjust
Pacote para Gráfico XBarra
